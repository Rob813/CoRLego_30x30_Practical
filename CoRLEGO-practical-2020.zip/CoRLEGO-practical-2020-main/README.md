# CoRLEGO-practical-2020
repository for CoRLEGO practical project 2020/21

it is based on previous work by Omer Eryilmaz: https://github.com/OBEryilmaz/MScProject
and COSIVINA, see: https://github.com/sschneegans/cosivina & https://dynamicfieldtheory.org/

